import { useState } from "react";

function App() {
  const [achievement, setAchievement] = useState("");
  const [aiFeedback, setAIFeedback] = useState("");

  const handleAnalyze = () => {
    setAIFeedback(
      "🧠 AI Feedback: You need to improve your frontend skills. We recommend a React course on Coursera."
    );
  };

  return (
    <div className="p-6 bg-gradient-to-br from-indigo-100 via-purple-100 to-pink-100 min-h-screen text-gray-800">
      <h1 className="text-5xl font-extrabold text-center mb-6 text-purple-700 drop-shadow">
        🌟 DCM Career Platform
      </h1>
      <p className="text-center mb-10 text-xl font-medium">
        Your AI-powered bilingual platform to boost IT skills & find tech jobs
      </p>

      <div className="max-w-4xl mx-auto bg-white shadow-xl rounded-xl p-6">
        <h2 className="text-2xl font-semibold text-purple-700 mb-4">1️⃣ Upload your achievement</h2>
        <textarea
          placeholder="Describe your project, competition, or product..."
          value={achievement}
          onChange={(e) => setAchievement(e.target.value)}
          className="w-full h-32 p-4 rounded border border-gray-300"
        />
        <button
          onClick={handleAnalyze}
          className="mt-4 bg-purple-600 text-white px-6 py-2 rounded hover:bg-purple-700"
        >
          🔍 Analyze with AI
        </button>
        {aiFeedback && <p className="text-green-700 font-medium mt-4">{aiFeedback}</p>}

        <h2 className="text-2xl font-semibold text-pink-700 mt-10">2️⃣ Browse Jobs</h2>
        <ul className="mt-2 space-y-2">
          <li className="bg-pink-50 p-4 rounded shadow">
            <strong>Frontend Intern at Techify</strong>
            <p>Remote | JavaScript, React</p>
          </li>
          <li className="bg-pink-50 p-4 rounded shadow">
            <strong>AI Assistant Builder - Freelance</strong>
            <p>Part-time | Prompt Engineering</p>
          </li>
        </ul>

        <h2 className="text-2xl font-semibold text-blue-700 mt-10">3️⃣ Recommended Courses</h2>
        <ul className="mt-2 space-y-2">
          <li className="bg-blue-50 p-4 rounded shadow">
            <strong>React for Beginners - Coursera</strong><br />
            <a
              href="https://www.coursera.org/learn/react"
              className="text-blue-600 underline"
              target="_blank"
            >Go to Course</a>
          </li>
          <li className="bg-blue-50 p-4 rounded shadow">
            <strong>Python for Everybody - Coursera</strong><br />
            <a
              href="https://www.coursera.org/specializations/python"
              className="text-blue-600 underline"
              target="_blank"
            >Go to Course</a>
          </li>
        </ul>
      </div>
    </div>
  );
}

export default App;